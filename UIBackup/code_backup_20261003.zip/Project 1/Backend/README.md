# Nông Trại Của Bé – Backend

API lưu kết quả học tập của bé (ASP.NET Core 8 + Entity Framework Core + SQLite).

## Chạy nhanh (Windows, bấm đúp)

| File | Việc |
|---|---|
| 0_bat_demo.bat | Bật mọi thứ để demo: SQL Server, database, server API, mở trình duyệt |
| 1_kiem_tra_may.bat | Kiểm tra đã cài .NET 8 SDK / SQL Server chưa |
| 2_chay_server.bat | Chạy server + mở Swagger |
| 3_chay_test.bat | Chạy 11 test tự động |
| 4_tao_database_sqlserver.bat | Tạo database SQL Server + dữ liệu demo + view/procedure |

## Chạy

```bash
cd src/NongTrai.Api
dotnet run
```

- Swagger (bấm thử API): http://localhost:5180/swagger
- Trang tạm: http://localhost:5180/
- File database: `src/NongTrai.Api/nongtrai.db` (tự tạo lần chạy đầu)

## Chọn database

Trong `src/NongTrai.Api/appsettings.json`:

```json
"Database": { "Provider": "Sqlite" }      // hoặc "SqlServer"
```

- `Sqlite`: file `nongtrai.db`, không cần cài gì.
- `SqlServer`: dùng chuỗi `ConnectionStrings:SqlServer` (mặc định `Server=localhost` = bản SQL Server cài mặc định; bản Express đổi thành `.\SQLEXPRESS`,
  database `NongTrai` tự tạo lần chạy đầu). LocalDB: `Server=(localdb)\MSSQLLocalDB;Database=NongTrai;Trusted_Connection=True`.

## Script SQL (thư mục `database/`)

| File | Nội dung |
|---|---|
| sqlserver/01_create_database.sql | Tạo database + 4 bảng, khóa, index, CHECK (khớp với code) |
| sqlserver/02_seed_demo.sql | Dữ liệu demo: 3 bé, 14 ngày gần nhất (chạy lại được) |
| sqlserver/03_reports.sql | 2 VIEW, stored procedure `sp_ChildReport`, 8 truy vấn báo cáo |
| sqlite/02_seed_demo.sql, sqlite/03_reports.sql | Bản tương ứng cho SQLite |
| tools/generate_demo.py | Sinh dữ liệu demo (mô phỏng đúng thuật toán AI trong game) |
| tools/test_sqlite_scripts.py | Chạy thử các script SQLite |

## Test

```bash
dotnet test
```

## API

| Phương thức | Đường dẫn | Ai gọi | Mô tả |
|---|---|---|---|
| GET | /api/health | – | Kiểm tra server |
| POST | /api/sessions | Game (cần `X-Api-Key`) | Gửi một lượt chơi; tự tạo/cập nhật hồ sơ bé; gửi trùng `clientSessionId` không bị lưu 2 lần |
| GET | /api/children | Trang phụ huynh | Danh sách bé |
| GET | /api/children/{id}/summary | Trang phụ huynh | Tỉ lệ đúng, mức thuộc, con hay nhầm, 14 ngày gần nhất |
| GET | /api/children/{id}/sessions?take=20 | Trang phụ huynh | Các lượt chơi gần đây |
| DELETE | /api/children/{id} | (cần `X-Api-Key`) | Xóa bé và toàn bộ dữ liệu |

## Cấu trúc database

```
Children (Id PK, Nickname, AvatarId, CreatedAt, LastSeenAt)
  1 ── n  Sessions (Id PK, ClientSessionId UNIQUE, ChildId FK, Game, StartedAt, EndedAt,
                    DifficultyLevel, QuestionCount, PerfectCount)
              1 ── n  Answers (Id PK, PlaySessionId FK, AnimalId, ChosenId, Correct, FirstTry, Seconds)
  1 ── n  Masteries (ChildId + AnimalId = PK, Score, UpdatedAt)
```
