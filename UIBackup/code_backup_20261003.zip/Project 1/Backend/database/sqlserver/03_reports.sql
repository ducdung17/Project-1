/* =====================================================================
   Nông Trại Của Bé – BÁO CÁO trên SQL Server
   Mở bằng SSMS > New Query. Phần 1 (VIEW + STORED PROCEDURE) chạy một lần bằng F5.
   Phần 2: bôi đen từng câu rồi F5 để chạy riêng câu đó.
   Giờ trong database là UTC; DATEADD(HOUR, 7, ...) đổi sang giờ Việt Nam khi gom theo ngày.
   Cột bit (Correct, FirstTry) không cộng trực tiếp được nên đổi sang số bằng CASE / CAST.
   ===================================================================== */
USE NongTrai;
GO

/* ---------------------------------------------------------------------
   PHẦN 1: VIEW và STORED PROCEDURE
   --------------------------------------------------------------------- */

-- Tổng quan mỗi bé: số lượt, số câu, tỉ lệ đúng ngay lần đầu, số con đã thuộc
CREATE OR ALTER VIEW dbo.vw_ChildOverview AS
WITH ans AS (
    SELECT s.ChildId,
           SUM(CAST(a.FirstTry AS int))                                        AS Questions,
           SUM(CASE WHEN a.FirstTry = 1 AND a.Correct = 1 THEN 1 ELSE 0 END)  AS FirstTryCorrect,
           AVG(CASE WHEN a.FirstTry = 1 THEN a.Seconds END)                    AS AvgSeconds
    FROM dbo.Sessions s
    JOIN dbo.Answers a ON a.PlaySessionId = s.Id
    GROUP BY s.ChildId
)
SELECT c.Id,
       c.Nickname,
       (SELECT COUNT(*) FROM dbo.Sessions s WHERE s.ChildId = c.Id)                     AS Sessions,
       COALESCE(ans.Questions, 0)                                                       AS Questions,
       CAST(100.0 * ans.FirstTryCorrect / NULLIF(ans.Questions, 0) AS decimal(5, 1))   AS FirstTryPct,
       CAST(ans.AvgSeconds AS decimal(5, 1))                                            AS AvgSeconds,
       (SELECT COUNT(*) FROM dbo.Masteries m WHERE m.ChildId = c.Id AND m.Score >= 0.8) AS MasteredAnimals,
       DATEADD(HOUR, 7, c.LastSeenAt)                                                   AS LastSeenVN
FROM dbo.Children c
LEFT JOIN ans ON ans.ChildId = c.Id;
GO

-- Hoạt động theo ngày (giờ Việt Nam) của từng bé
CREATE OR ALTER VIEW dbo.vw_DailyActivity AS
SELECT s.ChildId,
       CAST(DATEADD(HOUR, 7, s.StartedAt) AS date)                                AS DayVN,
       COUNT(DISTINCT s.Id)                                                       AS Sessions,
       SUM(CAST(a.FirstTry AS int))                                               AS Questions,
       CAST(100.0 * SUM(CASE WHEN a.FirstTry = 1 AND a.Correct = 1 THEN 1 ELSE 0 END)
            / NULLIF(SUM(CAST(a.FirstTry AS int)), 0) AS decimal(5, 1))           AS FirstTryPct
FROM dbo.Sessions s
JOIN dbo.Answers a ON a.PlaySessionId = s.Id
GROUP BY s.ChildId, CAST(DATEADD(HOUR, 7, s.StartedAt) AS date);
GO

-- Báo cáo đầy đủ một bé: 4 bảng kết quả (tổng quan, mức thuộc, cặp hay nhầm, 14 ngày)
-- Cách gọi:  EXEC dbo.sp_ChildReport @ChildId = N'demo-na';
CREATE OR ALTER PROCEDURE dbo.sp_ChildReport
    @ChildId nvarchar(64)
AS
BEGIN
    SET NOCOUNT ON;

    IF NOT EXISTS (SELECT 1 FROM dbo.Children WHERE Id = @ChildId)
    BEGIN
        RAISERROR(N'Không có bé với Id %s', 16, 1, @ChildId);
        RETURN;
    END;

    -- 1) Tổng quan
    SELECT * FROM dbo.vw_ChildOverview WHERE Id = @ChildId;

    -- 2) Mức thuộc từng con vật
    SELECT m.AnimalId,
           CAST(m.Score * 100 AS decimal(5, 0)) AS ScorePct,
           CASE WHEN m.Score >= 0.8 THEN N'Đã thuộc'
                WHEN m.Score >= 0.4 THEN N'Đang học'
                ELSE N'Mới làm quen' END        AS TrangThai
    FROM dbo.Masteries m
    WHERE m.ChildId = @ChildId
    ORDER BY m.Score DESC;

    -- 3) Top 5 cặp hay nhầm
    SELECT TOP (5) a.AnimalId AS ConDung, a.ChosenId AS BeChonNham, COUNT(*) AS SoLan
    FROM dbo.Answers a
    JOIN dbo.Sessions s ON s.Id = a.PlaySessionId
    WHERE s.ChildId = @ChildId AND a.Correct = 0
    GROUP BY a.AnimalId, a.ChosenId
    ORDER BY COUNT(*) DESC, a.AnimalId;

    -- 4) 14 ngày gần nhất, ngày không chơi vẫn có dòng (số 0) để vẽ biểu đồ liền mạch
    DECLARE @todayVN date = CAST(DATEADD(HOUR, 7, SYSUTCDATETIME()) AS date);
    WITH days AS (
        SELECT 0 AS n
        UNION ALL
        SELECT n + 1 FROM days WHERE n < 13
    )
    SELECT DATEADD(DAY, -d.n, @todayVN)  AS DayVN,
           COALESCE(v.Sessions, 0)       AS Sessions,
           COALESCE(v.Questions, 0)      AS Questions,
           v.FirstTryPct
    FROM days d
    LEFT JOIN dbo.vw_DailyActivity v
           ON v.ChildId = @ChildId AND v.DayVN = DATEADD(DAY, -d.n, @todayVN)
    ORDER BY DayVN;
END;
GO

/* ---------------------------------------------------------------------
   PHẦN 2: TRUY VẤN BÁO CÁO (bôi đen từng câu rồi F5)
   --------------------------------------------------------------------- */

-- [1] Bảng xếp hạng các bé
SELECT * FROM dbo.vw_ChildOverview ORDER BY FirstTryPct DESC;

-- [2] Báo cáo đầy đủ của bé Na (4 bảng kết quả)
EXEC dbo.sp_ChildReport @ChildId = N'demo-na';

-- [3] Mỗi bé hay nhầm con nào với con nào nhất (top 3, dùng hàm cửa sổ ROW_NUMBER)
WITH pairs AS (
    SELECT s.ChildId, a.AnimalId, a.ChosenId, COUNT(*) AS Times
    FROM dbo.Answers a
    JOIN dbo.Sessions s ON s.Id = a.PlaySessionId
    WHERE a.Correct = 0
    GROUP BY s.ChildId, a.AnimalId, a.ChosenId
), ranked AS (
    SELECT p.*, ROW_NUMBER() OVER (PARTITION BY p.ChildId ORDER BY p.Times DESC, p.AnimalId) AS Rk
    FROM pairs p
)
SELECT c.Nickname, r.AnimalId AS ConDung, r.ChosenId AS BeChonNham, r.Times AS SoLan
FROM ranked r
JOIN dbo.Children c ON c.Id = r.ChildId
WHERE r.Rk <= 3
ORDER BY c.Nickname, r.Rk;

-- [4] So sánh 3 trò chơi
SELECT s.Game,
       COUNT(DISTINCT s.Id)                                                        AS Sessions,
       SUM(CAST(a.FirstTry AS int))                                                AS Questions,
       CAST(100.0 * SUM(CASE WHEN a.FirstTry = 1 AND a.Correct = 1 THEN 1 ELSE 0 END)
            / NULLIF(SUM(CAST(a.FirstTry AS int)), 0) AS decimal(5, 1))            AS FirstTryPct,
       CAST(AVG(CASE WHEN a.FirstTry = 1 THEN a.Seconds END) AS decimal(5, 1))     AS AvgSeconds
FROM dbo.Sessions s
JOIN dbo.Answers a ON a.PlaySessionId = s.Id
GROUP BY s.Game
ORDER BY FirstTryPct;

-- [5] Con vật khó nhất với tất cả các bé (ít nhất 10 lần hỏi)
SELECT a.AnimalId,
       SUM(CAST(a.FirstTry AS int))                                                AS Asked,
       CAST(100.0 * SUM(CASE WHEN a.FirstTry = 1 AND a.Correct = 1 THEN 1 ELSE 0 END)
            / NULLIF(SUM(CAST(a.FirstTry AS int)), 0) AS decimal(5, 1))            AS FirstTryPct,
       CAST(AVG(CASE WHEN a.FirstTry = 1 THEN a.Seconds END) AS decimal(5, 1))     AS AvgSeconds
FROM dbo.Answers a
GROUP BY a.AnimalId
HAVING SUM(CAST(a.FirstTry AS int)) >= 10
ORDER BY FirstTryPct;

-- [6] Bé có tiến bộ không? Trước đó so với 7 ngày gần nhất
WITH tagged AS (
    SELECT s.ChildId, a.FirstTry, a.Correct,
           CASE WHEN CAST(DATEADD(HOUR, 7, s.StartedAt) AS date)
                     >= DATEADD(DAY, -6, CAST(DATEADD(HOUR, 7, SYSUTCDATETIME()) AS date))
                THEN N'2_7NgayGanNhat' ELSE N'1_TruocDo' END AS Period
    FROM dbo.Sessions s
    JOIN dbo.Answers a ON a.PlaySessionId = s.Id
)
SELECT c.Nickname, t.Period,
       SUM(CAST(t.FirstTry AS int))                                                AS Questions,
       CAST(100.0 * SUM(CASE WHEN t.FirstTry = 1 AND t.Correct = 1 THEN 1 ELSE 0 END)
            / NULLIF(SUM(CAST(t.FirstTry AS int)), 0) AS decimal(5, 1))            AS FirstTryPct
FROM tagged t
JOIN dbo.Children c ON c.Id = t.ChildId
GROUP BY c.Nickname, t.Period
ORDER BY c.Nickname, t.Period;

-- [7] AI chỉnh độ khó: DifficultyLevel là mức lúc KẾT THÚC lượt.
--     Lượt kết thúc ở mức cao là lượt bé làm tốt -> AI đã nâng độ khó đúng lúc.
SELECT s.DifficultyLevel,
       COUNT(DISTINCT s.Id)                                                        AS Sessions,
       CAST(100.0 * SUM(CASE WHEN a.FirstTry = 1 AND a.Correct = 1 THEN 1 ELSE 0 END)
            / NULLIF(SUM(CAST(a.FirstTry AS int)), 0) AS decimal(5, 1))            AS FirstTryPct
FROM dbo.Sessions s
JOIN dbo.Answers a ON a.PlaySessionId = s.Id
GROUP BY s.DifficultyLevel
ORDER BY s.DifficultyLevel;

-- [8] Kiểm tra index: xem kế hoạch thực thi (Ctrl+M rồi F5) -> phải thấy Index Seek trên IX_Sessions_ChildId_StartedAt
SELECT TOP (20) Id, Game, StartedAt, PerfectCount
FROM dbo.Sessions
WHERE ChildId = N'demo-na'
ORDER BY StartedAt DESC;
