/* =====================================================================
   Nông Trại Của Bé – TẠO DATABASE trên SQL Server
   Mở bằng SQL Server Management Studio (SSMS) > New Query > dán > Execute (F5).

   Không bắt buộc: server tự tạo y hệt các bảng này lần chạy đầu (EnsureCreated).
   Script này để đọc/duyệt thiết kế, hoặc tạo database trước khi chạy server.
   Tên bảng, cột, khóa và ràng buộc khớp đúng với AppDbContext trong code C#.
   ===================================================================== */

IF DB_ID(N'NongTrai') IS NULL
    CREATE DATABASE NongTrai COLLATE Vietnamese_CI_AS;  -- so sánh/sắp xếp chữ tiếng Việt đúng
GO

USE NongTrai;
GO

/* ---------------------------------------------------------------------
   Children: mỗi bé một dòng. Id là chuỗi GUID do game Unity tạo,
   nên game và server dùng chung một mã, không cần bước đăng ký riêng.
   --------------------------------------------------------------------- */
IF OBJECT_ID(N'dbo.Children', N'U') IS NULL
CREATE TABLE dbo.Children (
    Id          nvarchar(64)  NOT NULL,
    Nickname    nvarchar(32)  NOT NULL,
    AvatarId    int           NOT NULL,
    CreatedAt   datetime2     NOT NULL,   -- giờ UTC
    LastSeenAt  datetime2     NOT NULL,   -- giờ UTC
    CONSTRAINT PK_Children PRIMARY KEY (Id)
);
GO

/* ---------------------------------------------------------------------
   Sessions: một lượt chơi (8 câu) của một trò.
   ClientSessionId do game tạo + UNIQUE: game gửi lại khi mất mạng không bị lưu trùng.
   --------------------------------------------------------------------- */
IF OBJECT_ID(N'dbo.Sessions', N'U') IS NULL
CREATE TABLE dbo.Sessions (
    Id               int IDENTITY(1, 1) NOT NULL,
    ClientSessionId  nvarchar(64)  NOT NULL,
    ChildId          nvarchar(64)  NOT NULL,
    Game             nvarchar(16)  NOT NULL,   -- sound | shadow | food
    StartedAt        datetime2     NOT NULL,
    EndedAt          datetime2     NOT NULL,
    DifficultyLevel  int           NOT NULL,   -- 1..3 (độ khó do AI chỉnh)
    QuestionCount    int           NOT NULL,
    PerfectCount     int           NOT NULL,   -- số câu đúng ngay lần đầu
    CONSTRAINT PK_Sessions PRIMARY KEY (Id),
    CONSTRAINT FK_Sessions_Children_ChildId FOREIGN KEY (ChildId)
        REFERENCES dbo.Children (Id) ON DELETE CASCADE,
    CONSTRAINT CK_Sessions_Game  CHECK (Game IN ('sound', 'shadow', 'food')),
    CONSTRAINT CK_Sessions_Level CHECK (DifficultyLevel BETWEEN 1 AND 3),
    CONSTRAINT CK_Sessions_Time  CHECK (EndedAt >= StartedAt)
);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Sessions_ClientSessionId')
    CREATE UNIQUE INDEX IX_Sessions_ClientSessionId ON dbo.Sessions (ClientSessionId);
-- Truy vấn hay dùng nhất: "các lượt gần đây của một bé" -> index (ChildId, StartedAt)
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Sessions_ChildId_StartedAt')
    CREATE INDEX IX_Sessions_ChildId_StartedAt ON dbo.Sessions (ChildId, StartedAt);
GO

/* ---------------------------------------------------------------------
   Answers: mỗi lần bé chọn một đáp án, kể cả lần chọn lại sau khi sai.
   Correct = bé chọn đúng con; FirstTry = đây là lần chọn đầu tiên của câu hỏi.
   --------------------------------------------------------------------- */
IF OBJECT_ID(N'dbo.Answers', N'U') IS NULL
CREATE TABLE dbo.Answers (
    Id             int IDENTITY(1, 1) NOT NULL,
    PlaySessionId  int           NOT NULL,
    AnimalId       nvarchar(64)  NOT NULL,   -- con vật đúng của câu hỏi
    ChosenId       nvarchar(64)  NOT NULL,   -- con vật bé đã chọn
    Correct        bit           NOT NULL,
    FirstTry       bit           NOT NULL,
    Seconds        real          NOT NULL,   -- thời gian suy nghĩ
    CONSTRAINT PK_Answers PRIMARY KEY (Id),
    CONSTRAINT FK_Answers_Sessions_PlaySessionId FOREIGN KEY (PlaySessionId)
        REFERENCES dbo.Sessions (Id) ON DELETE CASCADE
);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Answers_PlaySessionId')
    CREATE INDEX IX_Answers_PlaySessionId ON dbo.Answers (PlaySessionId);
GO

/* ---------------------------------------------------------------------
   Masteries: mức thuộc 0..1 của từng bé với từng con vật (bản mới nhất từ AI trong game).
   Khóa ghép (ChildId, AnimalId): mỗi cặp đúng một dòng.
   --------------------------------------------------------------------- */
IF OBJECT_ID(N'dbo.Masteries', N'U') IS NULL
CREATE TABLE dbo.Masteries (
    ChildId    nvarchar(64)  NOT NULL,
    AnimalId   nvarchar(64)  NOT NULL,
    Score      real          NOT NULL,
    UpdatedAt  datetime2     NOT NULL,
    CONSTRAINT PK_Masteries PRIMARY KEY (ChildId, AnimalId),
    CONSTRAINT FK_Masteries_Children_ChildId FOREIGN KEY (ChildId)
        REFERENCES dbo.Children (Id) ON DELETE CASCADE,
    CONSTRAINT CK_Masteries_Score CHECK (Score >= 0 AND Score <= 1)
);
GO

PRINT N'Đã tạo xong database NongTrai.';
