using NongTrai.Api.Data;
using NongTrai.Api.Endpoints;
using NongTrai.Api.Services;

var builder = WebApplication.CreateBuilder(args);

// Database: SQLite (mặc định) hoặc SQL Server, chọn bằng "Database:Provider" trong appsettings.json.
builder.Services.AddDbContext<AppDbContext>((sp, options) =>
    DatabaseSetup.Configure(options, sp.GetRequiredService<IConfiguration>()));

builder.Services.AddSingleton(TimeProvider.System);
builder.Services.AddScoped<SessionService>();
builder.Services.AddScoped<StatsService>();

// Cho phép bản WebGL (chạy trên trang khác, ví dụ itch.io) và trang phụ huynh gọi API.
builder.Services.AddCors(o => o.AddDefaultPolicy(p => p
    .AllowAnyOrigin()
    .AllowAnyHeader()
    .WithMethods("GET", "POST", "DELETE")));

// Trang Swagger: xem và bấm thử API ngay trên trình duyệt (rất tiện khi demo).
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Tạo database và các bảng nếu chưa có (SQLite: tạo file; SQL Server: tạo database NongTrai).
using (IServiceScope scope = app.Services.CreateScope())
{
    AppDbContext db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    db.Database.EnsureCreated();
    app.Logger.LogInformation("Database: {Provider}", DatabaseSetup.ProviderName(app.Configuration));
}

app.UseCors();
app.UseSwagger();
app.UseSwaggerUI();
app.UseDefaultFiles();   // mở http://localhost:5180/ là vào trang phụ huynh (wwwroot/index.html)
app.UseStaticFiles();

app.MapNongTraiApi();

app.Run();

// Để project test (WebApplicationFactory<Program>) nhìn thấy lớp Program.
public partial class Program { }
