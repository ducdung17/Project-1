namespace NongTrai.Api.Data;

/// <summary>Một bé (hồ sơ). Id do game Unity tạo (chuỗi GUID) để hai bên khớp nhau.</summary>
public class Child
{
    public string Id { get; set; } = "";
    public string Nickname { get; set; } = "";
    public int AvatarId { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime LastSeenAt { get; set; }

    public List<PlaySession> Sessions { get; set; } = new();
    public List<Mastery> Masteries { get; set; } = new();
}

/// <summary>Một lượt chơi (8 câu) của một trò.</summary>
public class PlaySession
{
    public int Id { get; set; }

    /// <summary>Mã lượt do game tạo. Game gửi lại khi mất mạng thì không bị lưu trùng.</summary>
    public string ClientSessionId { get; set; } = "";

    public string ChildId { get; set; } = "";
    public Child? Child { get; set; }

    /// <summary>"sound" | "shadow" | "food".</summary>
    public string Game { get; set; } = "";
    public DateTime StartedAt { get; set; }
    public DateTime EndedAt { get; set; }
    public int DifficultyLevel { get; set; }
    public int QuestionCount { get; set; }
    public int PerfectCount { get; set; }

    public List<Answer> Answers { get; set; } = new();
}

/// <summary>Một lần bé chọn đáp án (kể cả lần chọn lại sau khi sai).</summary>
public class Answer
{
    public int Id { get; set; }
    public int PlaySessionId { get; set; }
    public PlaySession? PlaySession { get; set; }

    /// <summary>Con vật đúng của câu hỏi.</summary>
    public string AnimalId { get; set; } = "";
    /// <summary>Con vật bé đã chọn.</summary>
    public string ChosenId { get; set; } = "";
    public bool Correct { get; set; }
    public bool FirstTry { get; set; }
    public float Seconds { get; set; }
}

/// <summary>Mức thuộc (0..1) của bé với từng con vật — bản chụp mới nhất từ AI trong game.</summary>
public class Mastery
{
    public string ChildId { get; set; } = "";
    public Child? Child { get; set; }
    public string AnimalId { get; set; } = "";
    public float Score { get; set; }
    public DateTime UpdatedAt { get; set; }
}
