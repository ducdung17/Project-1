using System;
using System.Collections.Generic;

namespace NongTrai.Online
{
    // Các lớp dữ liệu gửi lên server. Dùng field public để JsonUtility chuyển được sang JSON.
    // Tên field khớp với SessionUploadDto bên server (server không phân biệt hoa/thường).

    [Serializable]
    public class AnswerPayload
    {
        public string animalId;
        public string chosenId;
        public bool correct;
        public bool firstTry;
        public float seconds;
    }

    [Serializable]
    public class MasteryPayload
    {
        public string animalId;
        public float score;
    }

    [Serializable]
    public class SessionPayload
    {
        public string clientSessionId;
        public string childId;
        public string nickname;
        public int avatarId;
        public string game;            // "sound" | "shadow" | "food"
        public string startedAt;       // ISO 8601 giờ UTC, ví dụ 2026-10-01T03:00:00.0000000Z
        public string endedAt;
        public int difficultyLevel;
        public List<AnswerPayload> answers = new List<AnswerPayload>();
        public List<MasteryPayload> mastery = new List<MasteryPayload>();
    }
}
