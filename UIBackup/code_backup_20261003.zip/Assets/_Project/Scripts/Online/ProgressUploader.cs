using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEngine.Networking;

namespace NongTrai.Online
{
    /// <summary>
    /// Gửi kết quả các lượt chơi lên server.
    /// - Mỗi lượt được cất vào hàng chờ (lưu trong PlayerPrefs) TRƯỚC khi gửi,
    ///   nên mất mạng hoặc tắt game giữa chừng cũng không mất dữ liệu.
    /// - Gửi thành công thì xóa khỏi hàng chờ; thất bại thì thử lại sau.
    /// - Server bỏ qua lượt đã nhận (theo clientSessionId) nên gửi lại không bị trùng.
    /// Tự tạo khi cần, không phải kéo vào scene.
    /// </summary>
    public class ProgressUploader : MonoBehaviour
    {
        const string QueueKey = "nongtrai.uploadqueue.v1";
        const int MaxQueued = 100;

        [Serializable]
        class Queue { public List<string> items = new List<string>(); }

        static ProgressUploader instance;

        ServerSettings settings;
        Queue queue;
        bool sending;
        float nextRetry;

        /// <summary>Số lượt đang chờ gửi (hiện trong bảng AI để kiểm tra khi demo).</summary>
        public static int PendingCount => instance != null ? instance.queue.items.Count : 0;

        /// <summary>Kết quả lần gửi gần nhất, ví dụ "OK 201" hoặc "Lỗi: Cannot connect".</summary>
        public static string LastStatus { get; private set; } = "chưa gửi";

        public static void Enqueue(SessionPayload payload)
        {
            ProgressUploader uploader = Ensure();
            if (uploader == null) return;
            uploader.queue.items.Add(JsonUtility.ToJson(payload));
            // Quá nhiều lượt chưa gửi: bỏ lượt cũ nhất (giữ lại lượt đầu nếu nó đang được gửi dở).
            int oldest = uploader.sending ? 1 : 0;
            while (uploader.queue.items.Count > MaxQueued) uploader.queue.items.RemoveAt(oldest);
            uploader.Save();
            uploader.TrySend();
        }

        static ProgressUploader Ensure()
        {
            if (instance != null) return instance;
            ServerSettings s = ServerSettings.Load();
            if (s == null || !s.enabled || string.IsNullOrEmpty(s.baseUrl)) return null;

            var go = new GameObject("ProgressUploader");
            DontDestroyOnLoad(go);
            instance = go.AddComponent<ProgressUploader>();
            instance.settings = s;
            instance.Load();
            return instance;
        }

        /// <summary>Mở game là thử gửi các lượt còn tồn từ lần chơi trước.</summary>
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        static void AutoStart()
        {
            ProgressUploader uploader = Ensure();
            if (uploader != null && uploader.queue.items.Count > 0) uploader.TrySend();
        }

        void Update()
        {
            if (!sending && queue.items.Count > 0 && Time.realtimeSinceStartup >= nextRetry)
                TrySend();
        }

        void TrySend()
        {
            if (!sending && queue.items.Count > 0) StartCoroutine(SendAll());
        }

        IEnumerator SendAll()
        {
            sending = true;
            string url = settings.baseUrl.TrimEnd('/') + "/api/sessions";

            while (queue.items.Count > 0)
            {
                string json = queue.items[0];
                using (var req = new UnityWebRequest(url, UnityWebRequest.kHttpVerbPOST))
                {
                    req.uploadHandler = new UploadHandlerRaw(Encoding.UTF8.GetBytes(json));
                    req.downloadHandler = new DownloadHandlerBuffer();
                    req.SetRequestHeader("Content-Type", "application/json");
                    if (!string.IsNullOrEmpty(settings.apiKey)) req.SetRequestHeader("X-Api-Key", settings.apiKey);
                    req.timeout = settings.timeoutSeconds;

                    UnityWebRequestAsyncOperation op;
                    try
                    {
                        op = req.SendWebRequest();
                    }
                    catch (InvalidOperationException e)
                    {
                        // Ví dụ "Insecure connection not allowed": Player Settings đang chặn http://
                        LastStatus = "Lỗi: " + e.Message;
                        Debug.LogWarning("[ProgressUploader] " + e.Message +
                            " -> Project Settings > Player > Allow downloads over HTTP = Always allowed.");
                        break;
                    }
                    yield return op;

                    long code = req.responseCode;
                    if (req.result == UnityWebRequest.Result.Success)
                    {
                        LastStatus = "OK " + code;
                        queue.items.RemoveAt(0);
                        Save();
                    }
                    else if (code == 400)
                    {
                        // Dữ liệu sai định dạng: gửi lại cũng vô ích -> bỏ, ghi log để sửa code.
                        LastStatus = "Bỏ lượt lỗi dữ liệu (400)";
                        Debug.LogWarning("[ProgressUploader] Server từ chối dữ liệu: " + req.downloadHandler.text + "\n" + json);
                        queue.items.RemoveAt(0);
                        Save();
                    }
                    else
                    {
                        // Mất mạng, server tắt, sai khóa API (401)...: giữ lại, thử sau.
                        LastStatus = "Lỗi: " + (code > 0 ? code.ToString() : req.error);
                        Debug.Log($"[ProgressUploader] Chưa gửi được ({LastStatus}), còn {queue.items.Count} lượt chờ.");
                        break;
                    }
                }
            }

            nextRetry = Time.realtimeSinceStartup + settings.retryEverySeconds;
            sending = false;
        }

        void Load()
        {
            string json = PlayerPrefs.GetString(QueueKey, "");
            queue = string.IsNullOrEmpty(json) ? new Queue() : (JsonUtility.FromJson<Queue>(json) ?? new Queue());
        }

        void Save()
        {
            PlayerPrefs.SetString(QueueKey, JsonUtility.ToJson(queue));
            PlayerPrefs.Save();
        }
    }
}
